export const firebaseConfig = {
    apiKey: "AIzaSyAnGFEWM0RToHityKdxzPFGS3SwyQw68ZU",
    authDomain: "spectogram-e37dd.firebaseapp.com",
    databaseURL: "https://spectogram-e37dd-default-rtdb.firebaseio.com",
    projectId: "spectogram-e37dd",
    storageBucket: "spectogram-e37dd.appspot.com",
    messagingSenderId: "43218892872",
    appId: "1:43218892872:web:9bed0f6ab2aa31b3bd807d"
  };
  